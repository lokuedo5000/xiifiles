// JUEGOS
const json_games = path.join(__dirname, 'json/Games.json');

/*LEER EL ARCHIVO JSON*/
const parse_games = fs.readFileSync(json_games, 'utf-8');

/*TRANSFORMAR JSON*/
let get_games = JSON.parse(parse_games);

/*LIMPIAR*/
let clear_recomendadoss = document.querySelector('#recomende_set');
clear_recomendadoss.innerHTML = '';

if (get_games.length == 0) {
  $('.apps_recomendados').hide();
}
for (var a = 0; a < get_games.length; a++) {
  clear_recomendadoss.innerHTML += `<div class="col s12 m3">
		                    			<div class="cover_recomende open" data-tipo="game" data-link="where.ejs?q=${get_games[a].ID}" style="background-image: url(${get_games[a].Imgimagen});">
		                    				<div class="name_recomende">
		                    					${textecorto(get_games[a].titulo, 40)}
		                    				</div>
		                    			</div>
		                    		</div>`;
}

function textecorto(text, max) {
  if (max > text.length) {
    return text;
  } else {
    return text.slice(0, max) + "...";
  }
  return
}


const rutafilejson = path.join(__dirname, 'json/generos.json');

/*LEER EL ARCHIVO JSON*/
const filejson = fs.readFileSync(rutafilejson, 'utf-8');

/*TRANSFORMAR JSON*/
let get_generos = JSON.parse(filejson);

/*LIMPIAR*/
let clear_generos = document.querySelector('#generos');
clear_generos.innerHTML = '';

/*LOAD GENEROS*/
for (var i = 0; i < get_generos.length; i++) {
  clear_generos.innerHTML += `<li><a href="./generos.ejs?q=${get_generos[i].item}">${get_generos[i].item}</a></li>`;
}

$('.open').click(function(event) {
  var tipo = $(this).attr('data-tipo');
  var dataLink = $(this).attr('data-link');
  if (tipo == 'game') {
    window.location.href = dataLink;
  }
});
