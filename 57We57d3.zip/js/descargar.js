/*LOAD GAMES HOME*/
function runfilejson(divid, namefile, ver) {
  /*RUTA DEL ARCHIVO*/
  const rutafilejson = path.join(__dirname, 'json', namefile);

  /*LEER EL ARCHIVO JSON*/
  const filejson = fs.readFileSync(rutafilejson, 'utf-8');

  /*TRANSFORMAR JSON*/
  let parsejson = JSON.parse(filejson);

  /*LIMPIAR*/
  let quitarelementos = document.querySelector(divid);
  quitarelementos.innerHTML = '';

  /*SELECCIONAR*/
  if (ver == "home") {
    $('.home_title_mas_recientes').show();

    /*MOSTRAR 12*/
    if (parsejson.length < 12) {
      var totalver = parsejson.length;
    } else {
      var totalver = 12;
    }

    for (var i = 0; i < totalver; i++) {
      if (parsejson[i].tipo == 'portable') {
        var portablees = `<span class="Resubido">
                                    <span class="texts" style="background-color: #16a085; font-size: 8px;">
                                        <span class="numero">
                                            100%
                                        </span>
                                        <span class="numerotext">
                                            portable
                                        </span>
                                        <span class="notext">textno</span>
                                    </span>
                                </span>`;
      } else {
        var portablees = '';
      }
      quitarelementos.innerHTML += `
                    <div class="col-app col-app-6">
                        <div class="articulos_app">
                            ${portablees}
                            <div class="overflowhide open_local" href="download.ejs?where=${parsejson[i].ID}">
                                <div class="contener_img" style="background-image: url(${parsejson[i].Imgimagen});">

                                </div>
                                <div class="title_game">
                                    <h6>${parsejson[i].titulo}</h6>
                                </div>
                            </div>
                        </div>
                    </div>`;
    }

    /*CAROUSEL*/

    setinfocarousel(textecorto(parsejson[0].titulo, 40), parsejson[0].peso, parsejson[0].fecha, '#generos_one', parsejson[0].genero, '.text_01', '.elpeso', '.fechapost', '.img_icono_01', parsejson[0].Imgimagen, parsejson[0].Imgbanner, '.img01');

    setinfocarousel(textecorto(parsejson[1].titulo, 40), parsejson[1].peso, parsejson[1].fecha, '#generos_two', parsejson[1].genero, '.text_02', '.elpeso_02', '.fechapost_02', '.img_icono_02', parsejson[1].Imgimagen, parsejson[1].Imgbanner, '.img02');

    setinfocarousel(textecorto(parsejson[2].titulo, 40), parsejson[2].peso, parsejson[2].fecha, '#generos_three', parsejson[2].genero, '.text_03', '.elpeso_03', '.fechapost_03', '.img_icono_03', parsejson[2].Imgimagen, parsejson[2].Imgbanner, '.img03');


    function setinfocarousel(titulo, peso, fecha, idGeneros, generos, classtitulo, classpeso, classfecha, classicono, iconoimg, banner, classbanner) {

      $(classicono).attr('style', 'background-image: url(' + iconoimg + ');');
      $(classbanner).attr('src', banner);

      $(classtitulo).text(titulo);
      $(classpeso).text(peso);
      $(classfecha).text(fecha);


      let idquitargeneros = document.querySelector(idGeneros);
      idquitargeneros.innerHTML = '';

      var vertextgeneros = generos;
      var gettextgene = vertextgeneros.split(",");
      for (var e = 0; e < gettextgene.length; e++) {
        idquitargeneros.innerHTML += `<a href="./generos.ejs?q=${gettextgene[e]}" class="geneseparate">${gettextgene[e]}</a>`;
      }
    }




    function textecorto(text, max) {
      if (max > text.length) {
        return text;
      } else {
        return text.slice(0, max) + "...";
      }
      return
    }
  } else if (ver == 'generos') {
    /*CODE SEARCH GENEROS*/
    getgereros();
    $('.home_title_mas_recientes').show();


  } else if (ver == 'categoria') {
    /*CODE SEARCH CATEGORIA*/
    getcategorias();
    $('.home_title_mas_recientes').show();

  } else if (ver == 'nivel') {
    /*CODE SEARCH NIVEL*/
    getrequisitos();
    $('.home_title_mas_recientes').show();

  } else if (ver == 'download') {
    /*CODE SEARCH DOWNLOAD*/
    $.urlParam = function(name) {
      var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
      if (results == null) {
        return null;
      } else {
        return decodeURI(results[1]) || 0;
      }
    }

    var where = $.urlParam('q').replace(/\++/g, ' ');
    var buscargame = parsejson.filter(obj => obj.ID == where);

    /*CORTAR TITLE*/
    if (buscargame[0].titulo.length < 25) {
      var titlecorto = buscargame[0].titulo;
    } else {
      var titlecorto = buscargame[0].titulo.slice(0, 25) + "...";
    }

    $('title').text(textecorto(buscargame[0].titulo, 18) + ' | CoffeeWeb');

    var titulo = $('title').text();
    $('.tituloapp').text(titulo);

    /*TITULO EN INFO*/
    $('.titlegame_down').text(textecorto(buscargame[0].titulo, 40));

    /*BANNER*/
    $('.banner_games').attr('style', 'background-image: url(' + buscargame[0].Imgbanner + ');');
    /*GENEROS*/

    let idquitargeneros = document.querySelector('#genegames');
    idquitargeneros.innerHTML = '';

    var vertextgeneros = buscargame[0].genero;
    var gettextgene = vertextgeneros.split(",");
    for (var e = 0; e < gettextgene.length; e++) {
      idquitargeneros.innerHTML += `<a href="./generos.ejs?q=${gettextgene[e]}" class="geneseparate">${gettextgene[e]}</a>`;
    }

    /*PESO*/
    $('.elpeso').text(buscargame[0].peso);

    /*Fecha Post*/
    $('.fechapost').text(buscargame[0].fecha);

    /*ICONO*/
    $('.imgicono').attr('style', 'background-image: url(' + buscargame[0].Imgimagen + ');');

    // ICONO LINK
    $('.verdada_links').attr('style', 'background-image: url(' + buscargame[0].Imgbanner + ');');
    $('#imgview').attr('src', buscargame[0].Imgimagen);
    $('.name_games').text(textecorto(buscargame[0].titulo, 40));
    $('.datos_server').text(' ' + buscargame[0].servidor + ' | ' + buscargame[0].tipo + ' | ' + buscargame[0].peso + ' ');
    $('.passfile').text(buscargame[0].password);
    /*DCP*/
    $('.text_dcp').text(textecorto(buscargame[0].descripcion, 500));

    /*REQUISITOS*/
    $('.requi_minimos').text(buscargame[0].Requiminimos);
    $('.requi_recomendados').text(buscargame[0].Requirecomendados);

    /*CAPTURAS*/
    let limpiarcaps = document.querySelector('#caps');
    limpiarcaps.innerHTML = '';

    var verdata_caps = buscargame[0].capturas;
    var getcaps = verdata_caps.split(",");

    if (getcaps.length > 2) {
      $('#caps').removeClass('contenedor_cap_2');
      $('#caps').addClass('contenedor_cap');
      var class_cap = 'caps caps-app';
    } else {
      $('#caps').removeClass('contenedor_cap');
      $('#caps').addClass('contenedor_cap_2');
      var class_cap = 'caps_2 caps-app_2';
    }
    for (var b = 0; b < getcaps.length; b++) {
      limpiarcaps.innerHTML += `<div class="${class_cap} open_zoom_img bg-info" data-img="${getcaps[b]}" style="background-image: url(${getcaps[b]});">
                                          <div class="showpoupimg">
                                              <div class="zoom_img cwI-zoomin">

                                              </div>
                                          </div>
                                      </div>`;
    }

    if (getcaps.length == 3) {
      let limpiarcaps = document.querySelector('#caps');
      limpiarcaps.innerHTML += `<div class="caps caps-app open_zoom_img bg-info" data-img="${buscargame[0].Imgbanner}" style="background-image: url(${buscargame[0].Imgbanner});">
                                          <div class="showpoupimg">
                                              <div class="zoom_img cwI-zoomin">

                                              </div>
                                          </div>
                                      </div>`;
    }

    /*ENLACES*/
    let limpiarenlaces = document.querySelector('#setenlaces');
    limpiarenlaces.innerHTML = '';

    var verenlaces = buscargame[0].enlaces;
    var getenlaces = verenlaces.split(",");
    for (var e = 0; e < getenlaces.length; e++) {
      limpiarenlaces.innerHTML += `<div class="header_info text_color_link">
                                            <div class="header_data_info header_data_info_max">
                                                <div class="text_igual">
                                                    Parte ${e+1}
                                                </div>
                                            </div>

                                            <div class="header_data_info header_data_info_max">
                                                <div class="text_igual max_text">
                                                    ${getenlaces[e]}
                                                </div>
                                            </div>

                                            <div class="header_data_info header_data_info_max">
                                                <div class="text_igual">
                                                    ${buscargame[0].ads}
                                                </div>
                                            </div>

                                            <div class="header_data_info header_data_info_max">
                                                <div class="des_btn_link open_link" data-link="${getenlaces[e]}" data-id="${buscargame[0].ID}" data-banner="${buscargame[0].Imgbanner}" data-title="${buscargame[0].titulo}" data-pass="${buscargame[0].password}">
                                                    Descargar
                                                </div>
                                            </div>
                                        </div>`;
    }

    $('.text_mas').click(function(event) {
      var leertext = $(this).attr('data-leer');
      if (leertext == 'mas') {
        $('.text_dcp').text(textecorto(buscargame[0].descripcion, 4000));
        $(this).text('Leer Menos');
        $(this).attr('data-leer', 'menos');
      } else {
        $('.text_dcp').text(textecorto(buscargame[0].descripcion, 500));
        $(this).text('Leer Mas');
        $(this).attr('data-leer', 'mas');
      }

    });




    function textecorto(text, max) {
      if (max > text.length) {
        return text;
      } else {
        return text.slice(0, max) + "...";
      }
      return
    }

  }

  /*SEARCH GENEROS*/
  function getgereros() {
    /*GET GENERO TEXT*/
    $.urlParam = function(name) {
      var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
      if (results == null) {
        return null;
      } else {
        return decodeURI(results[1]) || 0;
      }
    }

    var q = $.urlParam('q').replace(/\++/g, ' ');
    $('title').text(cortotext('Genero - ' + q, 18) + ' | CoffeeWeb');
    var titulo = $('title').text();
    $('.tituloapp').text(titulo);

    $('.home_title_mas_recientes').text('Genero - ' + q);

    function cortotext(text, max) {
      if (max > text.length) {
        return text;
      } else {
        return text.slice(0, max) + "...";
      }
      return
    }


    /*RUTA DEL ARCHIVO*/
    const filegetsearchgenero = path.join(__dirname, 'json', 'Games.json');

    /*LEER EL ARCHIVO JSON*/
    var getfilegenero = fs.readFileSync(filegetsearchgenero, 'utf-8');

    /*TRANSFORMAR JSON*/
    var data = JSON.parse(getfilegenero);

    var search_fields = ['genero'] //key fields to search for in dataset

    function search(keyword) {
      if (keyword.length < 1) // skip if input is empty
        return

      var results = []

      for (var i in data) { // iterate through dataset
        for (var u = 0; u < search_fields.length; u++) { // iterate through each key in dataset

          var rel = getRelevance(data[i][search_fields[u]], keyword) // check if there are matches

          if (rel == 0) // no matches...
            continue // ...skip

          results.push({
            relevance: rel,
            entry: data[i]
          }) // matches found, add to results and store relevance
        }
      }

      results.sort(compareRelevance) // sort by relevance

      for (i = 0; i < results.length; i++) {
        results[i] = results[i].entry // remove relevance since it is no longer needed
      }

      return results
    }

    function getRelevance(value, keyword) {
      value = value.toLowerCase() // lowercase to make search not case sensitive
      keyword = keyword.toLowerCase()

      var index = value.indexOf(keyword) // index of the keyword
      var word_index = value.indexOf(' ' + keyword) // index of the keyword if it is not on the first index, but a word

      if (index == 0) // value starts with keyword (eg. for 'Dani California' -> searched 'Dan')
        return 3 // highest relevance
      else if (word_index != -1) // value doesnt start with keyword, but has the same word somewhere else (eg. 'Dani California' -> searched 'Cali')
        return 2 // medium relevance
      else if (index != -1) // value contains keyword somewhere (eg. 'Dani California' -> searched 'forn')
        return 1 // low relevance
      else
        return 0 // no matches, no relevance
    }

    function compareRelevance(a, b) {
      return b.relevance - a.relevance
    }

    /*END*/

    /*CARGAR RESULTADOS*/
    /*RESULT JSON*/
    let resultgeneros = JSON.stringify(search(q), null, 2);

    /*PARSE JSON*/
    var encontrados = JSON.parse(resultgeneros);

    /*LIMPIAR*/
    let limpiargeneros = document.querySelector(divid);
    limpiargeneros.innerHTML = '';

    if (encontrados.length == 0) {
      let msapps = document.querySelector('#ms_apps');
      limpiargeneros.innerHTML = `<div class="mensajeapps text-center">
                                            <div class="open imagenwhatsapp" href="https://wa.me/573218858315">
                                                <img src="./imagens/whatsapp.png">
                                                <h6>lokuedo5000</h6>
                                            </div>
                                            <h5>¡Ups! Parece que no esta disponible el genero<br>por favor ayúdanos compartiendo juegos</h5>
                                        </div>`;
    }
    for (var i = 0; i < encontrados.length; i++) {
      if (encontrados[i].tipo == 'portable') {
        var portablees = `<span class="Resubido">
                                    <span class="texts" style="background-color: #16a085; font-size: 8px;">
                                        <span class="numero">
                                            100%
                                        </span>
                                        <span class="numerotext">
                                            portable
                                        </span>
                                        <span class="notext">textno</span>
                                    </span>
                                </span>`;
      } else {
        var portablees = '';
      }
      limpiargeneros.innerHTML += `
                    <div class="col-app col-app-6">
                        <div class="articulos_app">
                            ${portablees}
                            <div class="overflowhide open_local" href="where.ejs?q=${encontrados[i].ID}">
                                <div class="contener_img" style="background-image: url(${encontrados[i].Imgimagen};);">

                                </div>
                                <div class="title_game">
                                    <h6>${encontrados[i].titulo}</h6>
                                </div>
                            </div>
                        </div>
                    </div>`;
    }

  }

  /*END*/

  /*SEARCH CATEGORIAS*/
  function getcategorias() {
    /*GET GENERO TEXT*/
    $.urlParam = function(name) {
      var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
      if (results == null) {
        return null;
      } else {
        return decodeURI(results[1]) || 0;
      }
    }

    var q = $.urlParam('q').replace(/\++/g, ' ');
    $('title').text('Version - ' + q + ' | CoffeeWeb');
    $('.home_title_mas_recientes').text('Version - ' + q);


    /*RUTA DEL ARCHIVO*/
    const filegetsearchgenero = path.join(__dirname, '../../Downloads/FilesJson', 'Games.json');

    /*LEER EL ARCHIVO JSON*/
    var getfilegenero = fs.readFileSync(filegetsearchgenero, 'utf-8');

    /*TRANSFORMAR JSON*/
    var data = JSON.parse(getfilegenero);

    var search_fields = ['tipo'] //key fields to search for in dataset

    function search(keyword) {
      if (keyword.length < 1) // skip if input is empty
        return

      var results = []

      for (var i in data) { // iterate through dataset
        for (var u = 0; u < search_fields.length; u++) { // iterate through each key in dataset

          var rel = getRelevance(data[i][search_fields[u]], keyword) // check if there are matches

          if (rel == 0) // no matches...
            continue // ...skip

          results.push({
            relevance: rel,
            entry: data[i]
          }) // matches found, add to results and store relevance
        }
      }

      results.sort(compareRelevance) // sort by relevance

      for (i = 0; i < results.length; i++) {
        results[i] = results[i].entry // remove relevance since it is no longer needed
      }

      return results
    }

    function getRelevance(value, keyword) {
      value = value.toLowerCase() // lowercase to make search not case sensitive
      keyword = keyword.toLowerCase()

      var index = value.indexOf(keyword) // index of the keyword
      var word_index = value.indexOf(' ' + keyword) // index of the keyword if it is not on the first index, but a word

      if (index == 0) // value starts with keyword (eg. for 'Dani California' -> searched 'Dan')
        return 3 // highest relevance
      else if (word_index != -1) // value doesnt start with keyword, but has the same word somewhere else (eg. 'Dani California' -> searched 'Cali')
        return 2 // medium relevance
      else if (index != -1) // value contains keyword somewhere (eg. 'Dani California' -> searched 'forn')
        return 1 // low relevance
      else
        return 0 // no matches, no relevance
    }

    function compareRelevance(a, b) {
      return b.relevance - a.relevance
    }

    /*END*/

    /*CARGAR RESULTADOS*/
    /*RESULT JSON*/
    let resultgeneros = JSON.stringify(search(q), null, 2);

    /*PARSE JSON*/
    var encontrados = JSON.parse(resultgeneros);

    /*LIMPIAR*/
    let limpiargeneros = document.querySelector(divid);
    limpiargeneros.innerHTML = '';

    if (encontrados.length == 0) {
      let msapps = document.querySelector('#ms_apps');
      limpiargeneros.innerHTML = `<div class="mensajeapps text-center">
                                            <div class="open imagenwhatsapp" href="https://wa.me/573218858315">
                                                <img src="./imagens/whatsapp.png">
                                                <h6>lokuedo5000</h6>
                                            </div>
                                            <h5>¡Ups! Parece que no hay juegos disponible en version ${q}<br>por favor ayúdanos compartiendo juegos</h5>
                                        </div>`;
    }
    for (var i = 0; i < encontrados.length; i++) {

      if (encontrados[i].tipo == 'portable') {
        var portablees = `<span class="Resubido">
                                    <span class="texts" style="background-color: #16a085; font-size: 8px;">
                                        <span class="numero">
                                            100%
                                        </span>
                                        <span class="numerotext">
                                            portable
                                        </span>
                                        <span class="notext">textno</span>
                                    </span>
                                </span>`;
      } else {
        var portablees = '';
      }

      limpiargeneros.innerHTML += `
                    <div class="col-app col-app-6">
                        <div class="articulos_app">
                            ${portablees}
                            <div class="overflowhide open_local" href="download.ejs?where=${encontrados[i].ID}">
                                <div class="contener_img" style="background-image: url(${encontrados[i].Imgimagen};);">

                                </div>
                                <div class="title_game">
                                    <h6>${encontrados[i].titulo}</h6>
                                </div>
                            </div>
                        </div>
                    </div>`;
    }

  }

  /*END*/

  /*SEARCH NIVEL*/
  function getrequisitos() {
    /*GET GENERO TEXT*/
    $.urlParam = function(name) {
      var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
      if (results == null) {
        return null;
      } else {
        return decodeURI(results[1]) || 0;
      }
    }

    var q = $.urlParam('q').replace(/\++/g, ' ');
    $('title').text('Requisitos - ' + q + ' | CoffeeWeb');
    $('.home_title_mas_recientes').text('Requisitos - ' + q);


    /*RUTA DEL ARCHIVO*/
    const filegetsearchgenero = path.join(__dirname, '../../Downloads/FilesJson', 'Games.json');

    /*LEER EL ARCHIVO JSON*/
    var getfilegenero = fs.readFileSync(filegetsearchgenero, 'utf-8');

    /*TRANSFORMAR JSON*/
    var data = JSON.parse(getfilegenero);

    var search_fields = ['nivel'] //key fields to search for in dataset

    function search(keyword) {
      if (keyword.length < 1) // skip if input is empty
        return

      var results = []

      for (var i in data) { // iterate through dataset
        for (var u = 0; u < search_fields.length; u++) { // iterate through each key in dataset

          var rel = getRelevance(data[i][search_fields[u]], keyword) // check if there are matches

          if (rel == 0) // no matches...
            continue // ...skip

          results.push({
            relevance: rel,
            entry: data[i]
          }) // matches found, add to results and store relevance
        }
      }

      results.sort(compareRelevance) // sort by relevance

      for (i = 0; i < results.length; i++) {
        results[i] = results[i].entry // remove relevance since it is no longer needed
      }

      return results
    }

    function getRelevance(value, keyword) {
      value = value.toLowerCase() // lowercase to make search not case sensitive
      keyword = keyword.toLowerCase()

      var index = value.indexOf(keyword) // index of the keyword
      var word_index = value.indexOf(' ' + keyword) // index of the keyword if it is not on the first index, but a word

      if (index == 0) // value starts with keyword (eg. for 'Dani California' -> searched 'Dan')
        return 3 // highest relevance
      else if (word_index != -1) // value doesnt start with keyword, but has the same word somewhere else (eg. 'Dani California' -> searched 'Cali')
        return 2 // medium relevance
      else if (index != -1) // value contains keyword somewhere (eg. 'Dani California' -> searched 'forn')
        return 1 // low relevance
      else
        return 0 // no matches, no relevance
    }

    function compareRelevance(a, b) {
      return b.relevance - a.relevance
    }

    /*END*/

    /*CARGAR RESULTADOS*/
    /*RESULT JSON*/
    let resultgeneros = JSON.stringify(search(q), null, 2);

    /*PARSE JSON*/
    var encontrados = JSON.parse(resultgeneros);

    /*LIMPIAR*/
    let limpiargeneros = document.querySelector(divid);
    limpiargeneros.innerHTML = '';

    if (encontrados.length == 0) {
      let msapps = document.querySelector('#ms_apps');
      limpiargeneros.innerHTML = `<div class="mensajeapps text-center">
                                            <div class="open imagenwhatsapp" href="https://wa.me/573218858315">
                                                <img src="./imagens/whatsapp.png">
                                                <h6>lokuedo5000</h6>
                                            </div>
                                            <h5>¡Ups! Parece que no hay juegos disponible con requisitos ${q}<br>por favor ayúdanos compartiendo juegos</h5>
                                        </div>`;
    }
    for (var i = 0; i < encontrados.length; i++) {
      if (encontrados[i].tipo == 'portable') {
        var portablees = `<span class="Resubido">
                                    <span class="texts" style="background-color: #16a085; font-size: 8px;">
                                        <span class="numero">
                                            100%
                                        </span>
                                        <span class="numerotext">
                                            portable
                                        </span>
                                        <span class="notext">textno</span>
                                    </span>
                                </span>`;
      } else {
        var portablees = '';
      }
      limpiargeneros.innerHTML += `
                    <div class="col-app col-app-6">
                        <div class="articulos_app">
                            ${portablees}
                            <div class="overflowhide open_local" href="download.ejs?where=${encontrados[i].ID}">
                                <div class="contener_img" style="background-image: url(${encontrados[i].Imgimagen};);">

                                </div>
                                <div class="title_game">
                                    <h6>${encontrados[i].titulo}</h6>
                                </div>
                            </div>
                        </div>
                    </div>`;
    }

  }

  /*END*/

  // CARGAR LA WEB
  $('.open_local').click(function(event) {
    var verlink = $(this).attr('href');
    window.location.href = verlink;

  });

  $('.open').click(function(event) {
    var verlink = $(this).attr('href');
    event.preventDefault();
    shell.openExternal(verlink);

  });

  $('.open_zoom_img').click(function(event) {
    var imgver = $(this).attr('data-img');
    $('.zoomimg').html('<img src="' + imgver + '">');
    $('.zoomimg').show('fade');
    $('.zoomimg').addClass('zoomimg_show');
  });

  $('.zoomimg').click(function(event) {
    $('.zoomimg').hide('fade');
    $('.zoomimg').removeClass('zoomimg_show');
  });

  $('.open_link').click(function(event) {
    var link = $(this).attr('data-link');
    var id = $(this).attr('data-id');
    var bannerapp = $(this).attr('data-banner');
    var rutaapps = 'apps/coffeeweb/enlaces.ejs';
    var titlegame = $(this).attr('data-title');
    var passver = $(this).attr('data-pass');

    const canvas = document.getElementById('canvas');
    const img = document.getElementById('imgview');
    const ctxImagen = canvas.getContext('2d');
    ctxImagen.drawImage(img, 0, 0, img.width, img.height);
    var rgb = ctxImagen.getImageData(20, 100, 1, 1).data;
    // $('.bg_iocono').css('background', `linear-gradient(to bottom, #000000 0%, transparent 0%, rgb(${rgb[0]},${rgb[1]},${rgb[2]}) 100%)`);
    $('.bg_iocono').css('background', `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`);

    var numerolink = link.length / 2 - 11;

    $('#input_text_link').val(textecorto(link, numerolink) + '/password');
    $('#input_text_link').attr('data-link', link);

    $('.close_verdata_link').show();
    $('.verdada_links').show();

    function textecorto(text, max) {
      if (max > text.length) {
        return text;
      } else {
        return text.slice(0, max) + "/...";
      }
      return
    }
    // const detalles = {
    //     enlace: link,
    //     id: id,
    //     ruta: rutaapps,
    //     banner: bannerapp,
    //     titulo: titlegame,
    //     pass: passver
    // };

    // ipcRenderer.send('app--win-download', detalles);
  });

  $('.close_verdata_link').click(function(event) {
    $('.close_verdata_link').hide();
    $('.verdada_links').hide();
  });

  $('.openlinkya').click(function(event) {
    var el_link = $('#input_text_link').attr('data-link');

    event.preventDefault();
    shell.openExternal('https://3sk7d418al8u.com/sgskqgdm0?key=2035fd79fbd429c833c57c4a588f2767');
    shell.openExternal(el_link);

    $('.close_verdata_link').hide();
    $('.verdada_links').hide();
  });

}


const rutafilejson = path.join(__dirname, 'json/generos.json');

/*LEER EL ARCHIVO JSON*/
const filejson = fs.readFileSync(rutafilejson, 'utf-8');

/*TRANSFORMAR JSON*/
let get_generos = JSON.parse(filejson);

/*LIMPIAR*/
let clear_generos = document.querySelector('#generos');
clear_generos.innerHTML = '';

/*LOAD GENEROS*/
for (var i = 0; i < get_generos.length; i++) {
  clear_generos.innerHTML += `<li><a href="./generos.ejs?q=${get_generos[i].item}">${get_generos[i].item}</a></li>`;
}
