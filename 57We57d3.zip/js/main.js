const rutafilejson = path.join(__dirname, 'json/generos.json');

/*LEER EL ARCHIVO JSON*/
const filejson = fs.readFileSync(rutafilejson, 'utf-8');

/*TRANSFORMAR JSON*/
let get_generos = JSON.parse(filejson);

/*LIMPIAR*/
let clear_generos = document.querySelector('#generos');
clear_generos.innerHTML = '';

/*LOAD GENEROS*/
for (var i = 0; i < get_generos.length; i++) {
  clear_generos.innerHTML += `<li><a href="./generos.ejs?q=${get_generos[i].item}">${get_generos[i].item}</a></li>`;
}


// JUEGOS
const json_games = path.join(__dirname, 'json/Games.json');

/*LEER EL ARCHIVO JSON*/
const parse_games = fs.readFileSync(json_games, 'utf-8');

/*TRANSFORMAR JSON*/
let get_games = JSON.parse(parse_games);





// CAROUSEL
$('.carousel').carousel();
var carousel_active = false;

$(".carousel").hover(function() {
  let textplay = document.querySelector('#playcarousel').innerHTML = 'stop';
}, function() {
  let textplay = document.querySelector('#playcarousel').innerHTML = 'play';
});

setInterval(function() {
  let eltipo = document.querySelector('#playcarousel').innerHTML;
  if (eltipo == 'play') {
    $('.carousel').carousel('next');
  } else {

  }
}, 4000);

/*LIMPIAR*/
let clear_games = document.querySelector('#games_set');
clear_games.innerHTML = '';

if (get_games.length > 12) {
  var numerover = 12;
} else {
  var numerover = get_games.length;
}

/*LOAD GENEROS*/
for (var i = 0; i < numerover; i++) {
  var id = get_games[i].ID.slice(0, 4);


  clear_games.innerHTML += `<div class="col s12 m4">
							<canvas id="canvas_${id}" class="none"></canvas>
                            <div class="app_list open" data-tipo="game" data-link="where.ejs?q=${get_games[i].ID}">
                                <img src="${get_games[i].Imgimagen}" class="img_app" id="img_${id}">
	                            <div class="footer_cover_app bg_color_${id}">
	                            <h5 class="title-app" title="${get_games[i].titulo}">
	                                    ${textecorto(get_games[i].titulo, 40)}
	                                </h5>
	                                <h6 class="user-app">
	                                    @${get_games[i].user}
	                                </h6>
	                            </div>
                            </div>
                        </div>`;
}



function home() {
  $('.carousel_img-01').attr('src', get_games[0].Imgbanner);
  $('.carousel_img-02').attr('src', get_games[1].Imgbanner);
  $('.carousel_img-03').attr('src', get_games[2].Imgbanner);
  $('.carousel_img-04').attr('src', get_games[3].Imgbanner);

  $('.url_carousel-01').attr('href', 'where.ejs?q=' + get_games[0].ID);
  $('.url_carousel-02').attr('href', 'where.ejs?q=' + get_games[1].ID);
  $('.url_carousel-03').attr('href', 'where.ejs?q=' + get_games[2].ID);
  $('.url_carousel-04').attr('href', 'where.ejs?q=' + get_games[3].ID);
  for (var i = 0; i < get_games.length; i++) {
    var id = get_games[i].ID.slice(0, 4);
    const canvas = document.getElementById('canvas_' + id);
    const img = document.getElementById('img_' + id);
    const ctxImagen = canvas.getContext('2d');
    ctxImagen.drawImage(img, 0, 0, img.width, img.height);
    var rgb = ctxImagen.getImageData(20, 100, 1, 1).data;
    // $('.bg_color_'+id).css('background', `linear-gradient(to bottom, transparent 0%, rgb(${rgb[0]},${rgb[1]},${rgb[2]}) 0%, rgb(${rgb[0]},${rgb[1]},${rgb[2]}) 100%)`);
    $('.bg_color_' + id).css('background', `linear-gradient(to bottom, #CE5937 0%, transparent 0%, rgb(${rgb[0]},${rgb[1]},${rgb[2]}) 100%)`);
  }


  // UPDATE FILE JSON GAMES
  // JUEGOS
  var update_json_juegos = path.join(__dirname, '../../', 'web', 'config', 'cog_apps.json');
  var file_cog = fs.readFileSync(update_json_juegos, 'utf-8');
  var action_cog = JSON.parse(file_cog);

  var idweb = $('#idweb').text();
  // LEER LOS DATOS
  var name_datos = action_cog.filter(obj => obj.id == idweb);

  const data_update_down = {
    link: name_datos[0].link,
    id: name_datos[0].id,
    folder: name_datos[0].folder
  }


  ipcRenderer.send('app--update-games', data_update_down);

  var ver_que_action = path.join(__dirname, '../../', 'web', 'config', 'down');
  var leerdata = fs.readFileSync(ver_que_action, 'utf-8');

  if (leerdata == "home") {
    location.reload();
  } else if (leerdata == "apps") {
    $('.loader_download_data_json').remove();
  }

}



// RECOMENDADOS
var json_recomendados = get_games.filter(obj => obj.Recomendados == 'si');
/*LIMPIAR*/
let clear_recomendadoss = document.querySelector('#recomende_set');
clear_recomendadoss.innerHTML = '';

if (json_recomendados.length == 0) {
  $('.apps_recomendados').hide();
}
for (var a = 0; a < json_recomendados.length; a++) {
  clear_recomendadoss.innerHTML += `<div class="col s12 m3">
		                    			<div class="cover_recomende open" data-tipo="game" data-link="where.ejs?q=${json_recomendados[a].ID}" style="background-image: url(${json_recomendados[a].Imgimagen});">
		                    				<div class="name_recomende">
		                    					${textecorto(json_recomendados[a].titulo, 40)}
		                    				</div>
		                    			</div>
		                    		</div>`;
}

function textecorto(text, max) {
  if (max > text.length) {
    return text;
  } else {
    return text.slice(0, max) + "...";
  }
  return
}


$('.open').click(function(event) {
  var tipo = $(this).attr('data-tipo');
  var dataLink = $(this).attr('data-link');
  if (tipo == 'game') {
    window.location.href = dataLink;
  }
});



// function download() {
// 	/*CODE SEARCH DOWNLOAD*/
//         $.urlParam = function (name) {
//             var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
//             if (results == null) {
//                 return null;
//             } else {
//                 return decodeURI(results[1]) || 0;
//             }
//         }

//         var where = $.urlParam('q').replace(/\++/g, ' ');
//         var buscargame = get_games.filter(obj => obj.ID == where);

//         $('title').text(textecorto(buscargame[0].titulo, 18) + ' | CoffeeWeb');

//         function textecorto(text, max) {
//             if (max > text.length) {
//                 return text;
//             } else {
//                 return text.slice(0, max) + "...";
//             }
//             return
//         }

//       var titulo = $('title').text();
// 	  $('.tituloapp').text(titulo);

// }
// $('.open').click(function(event) {
// 	var tipo = $(this).attr('data-tipo');
// 	var dataLink = $(this).attr('data-link');
// 	if (tipo == 'game'){
// 		window.location.href = dataLink;
// 	}
// });
